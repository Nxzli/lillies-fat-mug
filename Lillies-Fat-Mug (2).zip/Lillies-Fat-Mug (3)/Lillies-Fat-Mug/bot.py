import discord
import asyncio
import random
from discord.ext import commands
from config import CONFIG
from messages import MESSAGES, RARE_MESSAGE
from logger import setup_logger
import logging

# Set up logging
logger = setup_logger()


class RandomMessageBot(commands.Bot):
    def __init__(self):
        # Setup intents with all privileges we need
        intents = discord.Intents.default()
        intents.message_content = True
        intents.messages = True  # Enable message-related events
        intents.guild_messages = True  # Enable server message events
        super().__init__(command_prefix='!', intents=intents)

        # Keep track of last message
        self.last_message = None

        # Register commands immediately
        self.remove_command('help')  # Remove default help command
        logger.info("Initializing commands...")

        # Define and register commands
        @self.command(name='lillie')
        async def lillie(ctx):
            """Sends a random message from the message list with a rare chance of special message"""
            logger.info(f"!lillie command received from {ctx.author.name}")
            try:
                # 0.01% chance (0.0001) for rare message
                if random.random() < 0.0001:
                    message = RARE_MESSAGE
                    logger.info("Rare message triggered via command!")
                else:
                    message = random.choice(MESSAGES)

                await ctx.send(message)
                logger.info(f"Sent message via command: {message[:50]}...")
            except Exception as e:
                logger.error(f"Error sending message via command: {str(e)}")
                await ctx.send("i fucking failed.....")

        @self.command(name='test')
        async def test(ctx):
            """Simple test command to verify command handling"""
            logger.info(f"Test command received from {ctx.author.name}")
            await ctx.send("<:hoho:1303933971461312574>")
            logger.info("Test command executed successfully")

        logger.info("Commands initialized successfully")

    def get_user_name(self, user):
        """Get custom name for user or fall back to their Discord username"""
        return CONFIG['user_names'].get(user.id, user.name)

    async def setup_hook(self):
        logger.info("Setup hook called")
        # Start the background task for random messages
        self.bg_task = asyncio.create_task(self.random_message_task())

    async def on_ready(self):
        logger.info(f'Bot is ready! Logged in as {self.user.name}')
        await self.change_presence(activity=discord.Game(name="mmhh,,, meow,,."))

    async def on_command_error(self, ctx, error):
        """Handle command errors and log them"""
        logger.error(f"Command error: {str(error)}")
        if isinstance(error, commands.CommandNotFound):
            logger.error("Command not found")
            await ctx.send("Command not found...")
        elif isinstance(error, commands.MissingPermissions):
            logger.error("Missing permissions")
            await ctx.send("You don't have permission to do that...")
        else:
            logger.error(f"Unexpected error type: {type(error)}")
            await ctx.send("Something went wrong with the command...")

    async def on_message(self, message):
        # Log command processing
        logger.info(f"Processing message: {message.content[:50]}...")

        try:
            # Process commands first
            await self.process_commands(message)
            logger.info("Command processing completed")
        except Exception as e:
            logger.error(f"Error processing commands: {str(e)}")

        # Don't respond to our own messages
        if message.author == self.user:
            return

        # Store the last message for potential random replies
        self.last_message = message

        # Get user's custom name
        user_name = self.get_user_name(message.author)

        # Check if the message is from the target user
        if message.author.id == CONFIG['target_user_id']:
            try:
                await message.reply(CONFIG['target_user_response'])
                logger.info(f"Replied to target user {user_name} in channel {message.channel.name}")
            except Exception as e:
                logger.error(f"Error replying to target user: {str(e)}")
        # 5% chance to reply to any message with a random message
        elif random.random() < 0.05 and self.last_message:
            try:
                random_response = random.choice(MESSAGES)
                await message.reply(f"hey {user_name}, {random_response}")
                logger.info(f"Random reply triggered for user {user_name}: {random_response[:50]}...")
            except Exception as e:
                logger.error(f"Error sending random reply: {str(e)}")

    async def random_message_task(self):
        await self.wait_until_ready()
        channel = self.get_channel(CONFIG['channel_id'])

        if not channel:
            logger.error(f"Could not find channel with ID {CONFIG['channel_id']}")
            return

        while not self.is_closed():
            try:
                # Get random delay within configured range
                delay = random.randint(
                    CONFIG['min_interval_seconds'],
                    CONFIG['max_interval_seconds']
                )

                # Wait for the random interval
                await asyncio.sleep(delay)

                # 0.01% chance for rare message
                if random.random() < 0.0001:
                    message = RARE_MESSAGE
                    logger.info("Rare message triggered in random task!")
                else:
                    message = random.choice(MESSAGES)

                await channel.send(message)
                logger.info(f"Sent message after {delay} seconds: {message[:50]}...")

            except Exception as e:
                logger.error(f"Error in random message task: {str(e)}")
                await asyncio.sleep(5)  # Wait a bit before retrying

    async def on_error(self, event_method, *args, **kwargs):
        logger.error(f"Error in {event_method}: {str(args[0])}")


async def main():
    bot = RandomMessageBot()
    await bot.start(CONFIG['token'])


def run_bot():
    try:
        asyncio.run(main())
    except Exception as e:
        logger.critical(f"Fatal error: {str(e)}")
        raise


if __name__ == "__main__":
    run_bot()
