import os

CONFIG = {
    # Discord Bot Token (from environment variable)
    'token': os.environ.get('DISCORD_TOKEN'),

    # Channel ID where messages will be sent
    'channel_id': 1300904665822793851,  # Replace with your channel ID

    # Timing configuration (in seconds)
    'min_interval_seconds': 300,  # 5 minutes
    'max_interval_seconds': 86400,  # 1 day

    # Logging configuration
    'log_level': 'INFO',
    'log_file': 'discord_bot.log',

    # Target user configuration
    'target_user_id': 642546684420947978,  # Set to the provided user ID
    'target_user_response': "Meow",  # Message to send when target user speaks

    # User name mappings (Discord User ID to custom name)
    'user_names': {
        642546684420947978: "Toni",  # Example mapping
        576187740526477322: "Mickey",
        286860004085071874: "Amber",
        197447919371157504: "Sandra",
        312860816565338112: "Jacob",
        341664666772045826: "Kyrah",
        110591536898539520: "Ryan",
        98468583234883584: "Anton"
    }
}