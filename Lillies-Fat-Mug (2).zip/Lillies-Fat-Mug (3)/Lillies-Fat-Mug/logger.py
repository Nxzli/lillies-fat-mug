import logging
from config import CONFIG

def setup_logger():
    """Set up and configure logging"""
    
    # Create logger
    logger = logging.getLogger('RandomMessageBot')
    logger.setLevel(getattr(logging, CONFIG['log_level']))
    
    # Create file handler
    file_handler = logging.FileHandler(CONFIG['log_file'])
    file_handler.setLevel(getattr(logging, CONFIG['log_level']))
    
    # Create console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(getattr(logging, CONFIG['log_level']))
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Add formatter to handlers
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    # Add handlers to logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger
